package ir.amin;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class irwebp extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "ir.amin.irwebp");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", ir.amin.irwebp.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.streams.File.InputStreamWrapper  _arraytoinputstream(byte[] _data) throws Exception{
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _in = null;
 //BA.debugLineNum = 21;BA.debugLine="Private Sub ArrayToInputStream (data()  As Byte) A";
 //BA.debugLineNum = 22;BA.debugLine="Dim In As InputStream";
_in = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
 //BA.debugLineNum = 23;BA.debugLine="In.InitializeFromBytesArray(data, 0, data.Length)";
_in.InitializeFromBytesArray(_data,(int) (0),_data.length);
 //BA.debugLineNum = 24;BA.debugLine="Return In";
if (true) return _in;
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return null;
}
public String  _bitmaptowebp(android.graphics.Bitmap _bmp,String _wppath,String _wpname,float _quality) throws Exception{
int _bts = 0;
java.nio.ByteBuffer _buffer = null;
byte[] _pixels = null;
int _height = 0;
int _width = 0;
int _stride = 0;
int _y = 0;
byte _b = (byte)0;
byte[] _encoded = null;
 //BA.debugLineNum = 44;BA.debugLine="Sub bitmapToWebp(bmp As AGBitmap,wpPath As String,";
 //BA.debugLineNum = 45;BA.debugLine="Dim bts As Int = bmp.getByteCount()";
_bts = _bmp.getByteCount();
 //BA.debugLineNum = 46;BA.debugLine="Dim buffer As JNByteBuffer=Null";
_buffer = (java.nio.ByteBuffer)(__c.Null);
 //BA.debugLineNum = 47;BA.debugLine="buffer= buffer.allocate(bts)";
_buffer = _buffer.allocate(_bts);
 //BA.debugLineNum = 48;BA.debugLine="bmp.copyPixelsToBuffer(buffer)";
_bmp.copyPixelsToBuffer((java.nio.Buffer)(_buffer));
 //BA.debugLineNum = 49;BA.debugLine="Dim pixels() As Byte  = buffer.array()";
_pixels = _buffer.array();
 //BA.debugLineNum = 51;BA.debugLine="Dim height As Int = bmp.getHeight";
_height = _bmp.getHeight();
 //BA.debugLineNum = 52;BA.debugLine="Dim width As Int = bmp.getWidth";
_width = _bmp.getWidth();
 //BA.debugLineNum = 53;BA.debugLine="Dim stride As Int = width * 4";
_stride = (int) (_width*4);
 //BA.debugLineNum = 55;BA.debugLine="For  y = 0 To pixels.Length-1 Step 4";
{
final int step9 = (int) (4);
final int limit9 = (int) (_pixels.length-1);
for (_y = (int) (0) ; (step9 > 0 && _y <= limit9) || (step9 < 0 && _y >= limit9); _y = ((int)(0 + _y + step9)) ) {
 //BA.debugLineNum = 56;BA.debugLine="Dim b As Byte =pixels(y)";
_b = _pixels[_y];
 //BA.debugLineNum = 57;BA.debugLine="pixels(y) =  pixels(y+2)";
_pixels[_y] = _pixels[(int) (_y+2)];
 //BA.debugLineNum = 58;BA.debugLine="pixels(y+2) = b";
_pixels[(int) (_y+2)] = _b;
 }
};
 //BA.debugLineNum = 61;BA.debugLine="Dim encoded() As Byte = WebPEncodeBGRA(pixels, wi";
_encoded = _webpencodebgra(_pixels,_width,_height,_stride,_quality);
 //BA.debugLineNum = 62;BA.debugLine="writeFileFromByteArray(wpPath,wpname, encoded)";
_writefilefrombytearray(_wppath,_wpname,_encoded);
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Private Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="End Sub";
return "";
}
public byte[]  _getbytesfrominputstream(anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _ips) throws Exception{
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
 //BA.debugLineNum = 15;BA.debugLine="Private Sub getBytesFromInputStream(ips As InputSt";
 //BA.debugLineNum = 16;BA.debugLine="Dim out As OutputStream";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
 //BA.debugLineNum = 17;BA.debugLine="out.InitializeToBytesArray(100) 'size not really";
_out.InitializeToBytesArray((int) (100));
 //BA.debugLineNum = 18;BA.debugLine="File.Copy2(ips, out)";
__c.File.Copy2((java.io.InputStream)(_ips.getObject()),(java.io.OutputStream)(_out.getObject()));
 //BA.debugLineNum = 19;BA.debugLine="Return out.ToBytesArray";
if (true) return _out.ToBytesArray();
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 3;BA.debugLine="Private Sub Initialize";
 //BA.debugLineNum = 4;BA.debugLine="End Sub";
return "";
}
public byte[]  _webpdecodeargb(byte[] _encoded,long _len,int[] _width,int[] _height) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 5;BA.debugLine="Private Sub WebPDecodeARGB(encoded() As Byte, len";
 //BA.debugLineNum = 6;BA.debugLine="Dim jo As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 7;BA.debugLine="jo.InitializeStatic(\"com.google.webp.libwebp\")";
_jo.InitializeStatic("com.google.webp.libwebp");
 //BA.debugLineNum = 8;BA.debugLine="Return jo.RunMethod(\"WebPDecodeARGB\",Array(encode";
if (true) return (byte[])(_jo.RunMethod("WebPDecodeARGB",new Object[]{(Object)(_encoded),(Object)(_len),(Object)(_width),(Object)(_height)}));
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return null;
}
public byte[]  _webpencodebgra(byte[] _pixels,int _width,int _height,int _stride,float _quality) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 10;BA.debugLine="Private Sub WebPEncodeBGRA(pixels() As Byte, width";
 //BA.debugLineNum = 11;BA.debugLine="Dim jo As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 12;BA.debugLine="jo.InitializeStatic(\"com.google.webp.libwebp\")";
_jo.InitializeStatic("com.google.webp.libwebp");
 //BA.debugLineNum = 13;BA.debugLine="Return jo.RunMethod(\"WebPEncodeBGRA\",Array(pixels";
if (true) return (byte[])(_jo.RunMethod("WebPEncodeBGRA",new Object[]{(Object)(_pixels),(Object)(_width),(Object)(_height),(Object)(_stride),(Object)(_quality)}));
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper  _webptobitmap(anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _inp) throws Exception{
byte[] _encoded = null;
int[] _width = null;
int[] _height = null;
byte[] _decoded = null;
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _b = null;
int[] _pixels = null;
com.rootsoft.bitmaplibrary.BitmapLibrary _bi = null;
 //BA.debugLineNum = 29;BA.debugLine="Sub webpToBitmap(inp As InputStream)As Bitmap";
 //BA.debugLineNum = 30;BA.debugLine="Dim encoded() As Byte =getBytesFromInputStream(in";
_encoded = _getbytesfrominputstream(_inp);
 //BA.debugLineNum = 31;BA.debugLine="Dim width(1) As Int";
_width = new int[(int) (1)];
;
 //BA.debugLineNum = 32;BA.debugLine="width(0)=0";
_width[(int) (0)] = (int) (0);
 //BA.debugLineNum = 33;BA.debugLine="Dim height(1) As Int";
_height = new int[(int) (1)];
;
 //BA.debugLineNum = 34;BA.debugLine="height(0)=0";
_height[(int) (0)] = (int) (0);
 //BA.debugLineNum = 36;BA.debugLine="Dim decoded() As Byte = WebPDecodeARGB(encoded, e";
_decoded = _webpdecodeargb(_encoded,(long) (_encoded.length),_width,_height);
 //BA.debugLineNum = 37;BA.debugLine="Dim b As ByteConverter";
_b = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 38;BA.debugLine="Dim pixels() As Int=b.IntsFromBytes(decoded)";
_pixels = _b.IntsFromBytes(_decoded);
 //BA.debugLineNum = 39;BA.debugLine="Dim bi As BitmapExtended";
_bi = new com.rootsoft.bitmaplibrary.BitmapLibrary();
 //BA.debugLineNum = 40;BA.debugLine="bi.Initialize(\"\")";
_bi.Initialize(ba,"");
 //BA.debugLineNum = 41;BA.debugLine="Return bi.createBitmap5(pixels,width(0),height(0)";
if (true) return (anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper(), (android.graphics.Bitmap)(_bi.createBitmap5(_pixels,_width[(int) (0)],_height[(int) (0)],_bi.ARGB_8888)));
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return null;
}
public String  _writefilefrombytearray(String _wppath,String _wpname,byte[] _data) throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Private Sub writeFileFromByteArray(wpPath As Strin";
 //BA.debugLineNum = 27;BA.debugLine="File.OpenOutput(File.DirRootExternal,\"a.webp\",Fal";
__c.File.OpenOutput(__c.File.getDirRootExternal(),"a.webp",__c.False).WriteBytes(_data,(int) (0),_data.length);
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
  static {
    System.loadLibrary("webp");
  } 
}
